import React from "react";
import { Routes, Route } from "react-router-dom";
import Login from "../pages/Login";
import SignUp from "../pages/Signup";
import Dashboard from "../pages/Dashboard";
import ManageUsers from "../pages/ManageUsers";
import UserForm from "../components/Userform";

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<SignUp />} />     
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/manageusers" element={<ManageUsers/>} />
      <Route path="/userform" element={<UserForm/>} />
      <Route path="*" element={<Login />} />
    </Routes>
  );
};

export default AppRoutes;
