import React from "react";
import { useNavigate } from "react-router-dom";
import { BarChart, PieChart } from "@mui/x-charts";

const Dashboard: React.FC = () => {
  const navigate = useNavigate();

  const storedUser = sessionStorage.getItem("currentUser");
  const user = storedUser ? JSON.parse(storedUser) : null;

  const storedUsers = localStorage.getItem("users");
  const allUsers = storedUsers ? JSON.parse(storedUsers) : [];

  const totalUsers = allUsers.length;
  const activeUsers = user ? 1 : 0;

  const defaultRoles = ["Admin", "Customer", "Retailer"];
  const roleCounts: Record<string, number> = allUsers.reduce(
    (count: Record<string, number>, curr: any) => {
      const role = curr.role || "Other";
      count[role] = (count[role] || 0) + 1;
      return count;
    },
    defaultRoles.reduce((count, role) => ({ ...count, [role]: 0 }), {})
  );

  const genderCounts = allUsers.reduce(
    (count: Record<string, number>, curr: any) => {
      const gender = curr.gender?.toLowerCase();
      if (gender === "male" || gender === "female") {
        count[gender] = (count[gender] || 0) + 1;
      }
      return count;
    },
    { male: 0, female: 0 }
  );

  const genderData = [
    { id: 0, value: genderCounts.male, label: "Male", color: "#3B82F6" },
    { id: 1, value: genderCounts.female, label: "Female", color: "#EC4899" },
  ];

  const signupCountsByMonth = allUsers.reduce((count: any, user: any) => {
    if (user.createdAt) {
      const date = new Date(user.createdAt);
      const month = date.toLocaleString("default", { month: "short" });
      count[month] = (count[month] || 0) + 1;
    }
    return count;
  }, {});

  const signupMonths = Object.keys(signupCountsByMonth);
  const signupCounts = Object.values(signupCountsByMonth) as number[];

  const handleLogout = () => {
    sessionStorage.clear();
    navigate("/login");
  };

  const handleManageUsers = () => {
    navigate("/manageusers");
  };

  return (
    <>
      <div className="fixed w-full h-20 bg-white/30 shadow-md flex items-center px-6 justify-between z-20 backdrop-blur-md">
        <div className="flex items-center text-3xl italic font-bold text-white">
          User Management Portal
        </div>
        <div className="flex items-center space-x-3">
          <div className="italic text-white font-semibold text-xl">
            {user ? user.fullname : "Guest"}
          </div>
          <button
            onClick={handleLogout}
            className="bg-red-600 text-white font-bold px-3 py-1 rounded-md active:scale-95 transition"
          >
            Logout
          </button>
        </div>
      </div>

      <div className="flex flex-col min-h-screen justify-start items-center mt-30 px-10 space-y-10">
        <div className="italic text-5xl text-white font-semibold text-center">
          Welcome Back, {user?.fullname}!
        </div>

        <div className="max-w-4xl text-center text-lg leading-relaxed bg-white/80 p-6 rounded-xl shadow-md">
          <p>
            The <strong>User Management Portal</strong> allows administrators to
            manage user countounts, assign roles, and monitor overall system
            activity. This dashboard provides a quick overview of user
            distribution and platform engagement metrics.
          </p>
        </div>

        <button
          onClick={handleManageUsers}
          className=" bg-white text-blue-800 font-semibold px-6 py-3 rounded-md hover:bg-blue-50 active:scale-95 transition shadow-md"
        >
          Manage Users
        </button>

        <div className="grid grid-cols-2 gap-8">
          <div className=" bg-white/80 backdrop-blur-md rounded-xl p-6 shadow-lg text-center">
            <h3 className="text-2xl font-bold text-green-600">{totalUsers}</h3>
            <p className="text-lg">Total Users</p>
          </div>

          <div className=" bg-white/80 backdrop-blur-md rounded-xl p-6 shadow-lg text-center">
            <h3 className="text-2xl font-bold text-red-600">{activeUsers}</h3>
            <p className="text-lg">Active Users</p>
          </div>
        </div>

        <h2 className="text-2xl mb-4 text-center text-black font-bold">
          User Role Distribution
        </h2>
        <div className="grid grid-cols-3 gap-12">
          {Object.entries(roleCounts).map(([role, count]) => {
            const roleColorMap: Record<string, string> = {
              Admin: "text-red-600",
              Customer: "text-green-600",
              Retailer: "text-blue-600",
            };
            const colorClass = roleColorMap[role] || "text-gray-600";

            return (
              <div
                key={role}
                className="bg-white/80 backdrop-blur-md rounded-xl p-6 shadow-lg text-center"
              >
                <h3 className="text-lg">{role}</h3>
                <p className={`text-xl font-semibold ${colorClass}`}>{count}</p>
              </div>
            );
          })}
        </div>

        <div className=" bg-white/80 p-5 mb-10 rounded-lg shadow-lg mt-10">
          <h2 className="text-2xl mb-4 text-center font-semibold">
            User Gender Distribution
          </h2>
          <PieChart
            series={[
              {
                data: genderData,
                outerRadius: 120,
              },
            ]}
            width={320}
            height={300}
          />
        </div>

        <div className=" bg-white/80 p-5 mb-10 rounded-lg shadow-lg mt-10">
          <h2 className="text-2xl mb-4 text-center font-semibold">
            Monthly User Signups
          </h2>
          <BarChart
            xAxis={[
              {
                scaleType: "band",
                data: signupMonths,
              },
            ]}
            series={[
              {
                data: signupCounts,
                color: "#2563EB",
              },
            ]}
            width={400}
            height={300}
          />
        </div>
      </div>
    </>
  );
};

export default Dashboard;
