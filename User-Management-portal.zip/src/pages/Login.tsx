import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Login() {
  const [data, setData] = useState({ mail: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const storedData = localStorage.getItem("users");

    if (storedData) {
      const usersData = JSON.parse(storedData);

      const foundUser = usersData.find(
        (user: any) => user.email === data.mail && user.password === data.password
      );

      if (foundUser) {
        sessionStorage.setItem("currentUser", JSON.stringify(foundUser));
        toast.success("Login successful!");
        navigate("/dashboard");
      } else {
        toast.error("Invalid Email or Password!");
      }
    } else {
      toast.info("No registered users found! Please sign up first.");
    }
  };

  return (
    <div className="flex flex-col min-h-screen justify-center items-center">
      <h1 className="mb-6 text-3xl font-bold text-white drop-shadow-md">
        Welcome Back
      </h1>

      <form
        onSubmit={handleSubmit}
        className="rounded-xl p-8 bg-white border-2 border-gray-300 shadow-2xl w-96"
      >
        <input
          type="email"
          name="mail"
          value={data.mail}
          onChange={handleChange}
          placeholder="Email"
          required
          className="rounded mb-4 mt-4 p-1.5 border-2 border-gray-300 w-full focus:outline-none focus:border-blue-500"
        />

        <input
          type="password"
          name="password"
          value={data.password}
          onChange={handleChange}
          placeholder="Password"
          required
          className="rounded mb-6 p-1.5 border-2 border-gray-300 w-full focus:outline-none focus:border-blue-500"
        />

        <div className="flex justify-center mb-4">
          <button
            type="submit"
            className="border-2 rounded-md p-2 bg-green-700 text-white w-32 font-semibold active:scale-95 transition-transform duration-150 hover:bg-green-800"
          >
            Login
          </button>
        </div>

        <p className="text-center text-sm text-gray-700">
          Not a member?{" "}
          <Link
            to="/signup"
            className="text-blue-600 font-semibold hover:underline hover:text-blue-800"
          >
            Sign Up
          </Link>
        </p>
      </form>
    </div>
  );
}

export default Login;
