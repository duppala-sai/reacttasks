import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

  const ManageUsers: React.FC = () => {
  const navigate = useNavigate();

  const storedUsers = localStorage.getItem("users");
  const allUsers = storedUsers ? JSON.parse(storedUsers) : [];

  const handleUsers = () => {
   navigate("/userform");

  };

  const handleDelete = (email: string) => {
    const updatedUsers = allUsers.filter((user: any) => user.email !== email);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
    window.location.reload(); 
  };

  const handleEdit = (email: string) => {
  const user = allUsers.find((u: any) => u.email === email);
  navigate("/userform", { state: { user } });
};


  return (
    <>
      <div className="fixed w-full h-20 bg-white/30 shadow-md flex items-center px-6 justify-between z-20 backdrop-blur-md">
        <div className="flex items-center text-3xl italic font-bold text-white">
          User Management Portal
        </div>
        <div className="flex items-center space-x-3">
          <Link
            to="/dashboard"
            className="text-white italic font-bold text-lg underline"
          >
            Back to Dashboard
          </Link>
        </div>
      </div>

      <div className="flex flex-col items-center justify-start mt-28 px-10 text-gray-900">
        <div className="text-white text-center text-lg italic font-semibold max-w-4xl mx-auto mb-6">
          The Manage Users panel serves as the central hub for overseeing all user accounts within the system.
          Administrators can view comprehensive user details, register new users, modify existing profiles, and remove inactive or unauthorized accounts.
        </div>

        <button
          onClick={handleUsers}
          className="bg-green-600 text-white font-semibold px-4 py-2 mb-7 rounded-md transition hover:bg-green-700"
        >
          Add User
        </button>

        <div className="w-full max-w-5xl mb-10">
          <table className="w-full border-collapse border border-gray-600 text-left bg-white shadow-md">
            <thead className="bg-gray-300">
              <tr>
                <th className="border border-gray-400 px-4 py-2">Full Name</th>
                <th className="border border-gray-400 px-4 py-2">Email</th>
                <th className="border border-gray-400 px-4 py-2">Role</th>
                <th className="border border-gray-400 px-4 py-2">Gender</th>
                <th className="border border-gray-400 px-4 py-2">Mobile</th>
                <th className="border border-gray-400 px-4 py-2">DOB</th>
                <th className="border border-gray-400 px-4 py-2 text-center">Actions</th>
              </tr>
            </thead>

            <tbody>
              {allUsers.map((user: any, i: number) => (
                <tr key={i}>
                  <td className="border border-gray-400 px-4 py-2">{user.fullname}</td>
                  <td className="border border-gray-400 px-4 py-2">{user.email}</td>
                  <td className="border border-gray-400 px-4 py-2">{user.role}</td>
                  <td className="border border-gray-400 px-4 py-2">{user.gender}</td>
                  <td className="border border-gray-400 px-4 py-2">{user.mobile}</td>
                  <td className="border border-gray-400 px-4 py-2">{user.dob}</td>
                  <td className="border border-gray-400 px-4 py-2 flex justify-center space-x-2">
                    <button
                      onClick={() => handleEdit(user.email)}
                      className="bg-blue-600 text-white px-3 py-1 rounded-md text-sm hover:bg-blue-700"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(user.email)}
                      className="bg-red-600 text-white px-3 py-1 rounded-md text-sm hover:bg-red-700"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default ManageUsers;
