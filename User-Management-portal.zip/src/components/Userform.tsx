import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { toast } from "react-toastify";
import { useNavigate, useLocation } from "react-router-dom";

const schema = yup.object().shape({
  fullname: yup.string().required("Full Name is required"),
  email: yup
    .string()
    .email("Invalid email format")
    .matches(/^[A-Za-z0-9._%+-]+@(gmail|hotmail)\.com$/, "Email must be valid")
    .required("Email is required"),
  password: yup.string().min(6, "Password must be at least 6 characters"),
  role: yup.string().required("Role is required"),
  mobile: yup.string().matches(/^\d{10}$/, "Mobile must be 10 digits").required("Mobile is required"),
  gender: yup.string().required("Gender is required"),
  dob: yup
    .date()
    .nullable()
    .transform((value, originalValue) => (originalValue === "" ? null : value))
    .required("Date of Birth is required"),
});

const UserForm: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const userToEdit = location.state?.user || null;

  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    if (userToEdit) {
      Object.keys(userToEdit).forEach((key) => {
        setValue(key as any, userToEdit[key]);
      });
    }
  }, [userToEdit, setValue]);

  const onSubmit = (data: any) => {
    data.dob = new Date(data.dob).toISOString().split("T")[0];
    const existingUsers = JSON.parse(localStorage.getItem("users") || "[]");

    if (userToEdit) {
      const updatedUsers = existingUsers.map((u: any) =>
        u.email === userToEdit.email ? { ...data } : u
      );
      localStorage.setItem("users", JSON.stringify(updatedUsers));
      toast.success("User updated successfully!");
    } else {
      existingUsers.push({ ...data, createdAt: new Date().toISOString() });
      localStorage.setItem("users", JSON.stringify(existingUsers));
      toast.success("User added successfully!");
    }

    navigate("/manageusers");
  };

  const handleCancel = () => {
    navigate("/manageusers");
  };

  return (
    <div className="flex flex-col min-h-screen justify-center items-center">
      <h1 className="mt-10 mb-3 text-2xl text-white">
        {userToEdit ? "Edit User" : "Add New User"}
      </h1>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="rounded-xl p-9 mb-12 bg-white border-2 border-gray-300 shadow-xl w-96"
      >
        <div>
          <label className="block">Full Name</label>
          <input type="text" {...register("fullname")} className="rounded mb-2 p-1 border-2 border-gray-300 w-full" />
          {errors.fullname && <p className="text-red-500">{errors.fullname.message}</p>}
        </div>

        <div>
          <label className="block">Email</label>
          <input type="email" {...register("email")} className="rounded mb-2 p-1 border-2 border-gray-300 w-full" disabled={!!userToEdit} />
          {errors.email && <p className="text-red-500">{errors.email.message}</p>}
        </div>

        {!userToEdit && (
          <div>
            <label className="block">Password</label>
            <input type="password" {...register("password")} className="rounded mb-2 p-1 border-2 border-gray-300 w-full" />
            {errors.password && <p className="text-red-500">{errors.password.message}</p>}
          </div>
        )}

        <div>
          <label className="block">Role</label>
          <select {...register("role")} className="rounded mb-2 p-1 border-2 border-gray-300 w-full">
            <option value="">Select role</option>
            <option value="Admin">Admin</option>
            <option value="Customer">Customer</option>
            <option value="Retailer">Retailer</option>
          </select>
          {errors.role && <p className="text-red-500">{errors.role.message}</p>}
        </div>

        <div>
          <label className="block">Mobile Number</label>
          <input type="tel" {...register("mobile")} maxLength={10} className="rounded mb-2 p-1 border-2 border-gray-300 w-full" />
          {errors.mobile && <p className="text-red-500">{errors.mobile.message}</p>}
        </div>

        <div>
          <label className="block mb-2 mt-2">
            Gender:
            <input type="radio" {...register("gender")} value="Male" className="ml-3" /> Male
            <input type="radio" {...register("gender")} value="Female" className="ml-3" /> Female
          </label>
          {errors.gender && <p className="text-red-500">{errors.gender.message}</p>}
        </div>

        <div>
          <label className="block">Date of Birth</label>
          <input type="date" {...register("dob")} className="rounded mb-2 p-1 border-2 border-gray-300 w-full" />
          {errors.dob && <p className="text-red-500">{errors.dob.message}</p>}
        </div>

        <div className="flex justify-between mt-6">
          <button
            type="submit"
            className={`border-2 rounded-md p-1 w-32 text-white ${userToEdit ? "bg-blue-700 hover:bg-blue-800" : "bg-green-700 hover:bg-green-800"}`}
          >
            {userToEdit ? "Update" : "Add"}
          </button>

          <button
            type="button"
            onClick={handleCancel}
            className="border-2 rounded-md p-1 w-32 bg-gray-500 text-white hover:bg-gray-600"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default UserForm;
