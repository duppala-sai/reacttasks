import React from "react";
import { Link } from "react-router-dom";

const Home: React.FC = () => {
  return (
    <div
      className="min-h-screen bg-cover bg-center bg-fixed flex flex-col overflow-auto"
      style={{ backgroundImage: "url('/images/background.png')" }}
    >
      {/* Header */}
      <header className="flex justify-between items-center p-6">
        {/* Logo and Title */}
        <div className="flex items-center">
          <img src="/images/icon.png" alt="Logo" className="h-12 w-12 mr-3" />
          <h1 className="text-white text-xl font-semibold font-serif tracking-wide">UMP</h1>
        </div>

        {/* Auth Buttons */}
        <div className="flex space-x-4 px-4 py-2 rounded-lg">
          <Link
            to="/login"
className="px-4 py-1 border border-white text-white rounded-md bg-green-600  transition-transform duration-200 ease-in-out transform hover:scale-105">
            Login
          </Link>
          <Link
            to="/signup"
            className="px-4 py-1 border border-white text-white rounded-md hover:bg-blue-600 hover:text-white transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Signup
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-col grow justify-center items-start text-white text-left px-4 ml-24">
        <h2 className="text-4xl font-bold mb-4">Welcome to the Portal</h2>
        <p className="text-lg max-w-2xl mb-6">
          UMP (User Management Portal) helps you easily manage users with powerful
          control tools. Whether it's access, roles, or permissions—you’re in charge.
        </p>

        {/* Action Buttons */}
        <div className="flex space-x-4 mt-4">
          <Link
            to="/login"
className="px-4 py-1 border border-white text-white rounded-md bg-green-600  transition-transform duration-200 ease-in-out transform hover:scale-105">
        
            Get Started
          </Link>
          <Link
            to="/signup"
            className="px-4 py-1 border border-white text-white rounded-md hover:bg-blue-600 hover:text-white transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Create Account
          </Link>
        </div>
      </main>
    </div>
  );
};

export default Home;
