import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import "./App.css";

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <BrowserRouter>
      <div
        className="fixed top-0 left-0 w-full h-full bg-cover bg-center"
        style={{ backgroundImage: "url(/images/background.jpg)" }}
      />

      <div className="flex flex-col relative z-10 min-h-screen ">
        <App />
      </div>
    </BrowserRouter>
  </React.StrictMode>
);
