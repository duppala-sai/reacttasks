import React from "react";
import Header from "../components/header";
import Role from "../components/visuals/Role";
import UserActivity from "../components/visuals/userActivity";
import AgeDistribution from "../components/visuals/AgeDistribution";
import SignupTrends from "../components/visuals/signupTrends";
import GenderDistribution from "../components/visuals/Gender";

const Dashboard: React.FC = () => {
  const storedUsers = localStorage.getItem("userdata");
  const allUsers = storedUsers ? JSON.parse(storedUsers) : [];

  return (
    <>
      <Header />

        <div className="flex flex-col items-center bg-blue-50 mt-20 px-6 md:px-12 space-y-8">

          <div className="text-center">
            <h1 className="text-3xl md:text-4xl mt-10 font-bold text-purple-800 tracking-wide">
              Platform Insights
            </h1>
            <p className="mt-2 text-lg md:text-xl text-gray-700">
            Breakdown of user roles, behavior analytics, and monthly signup patterns.</p>
          </div>

          <Role allUsers={allUsers} />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-18 mt-10 mb-10 w-full max-w-5xl">
  {[UserActivity, SignupTrends, GenderDistribution, AgeDistribution].map((ChartComponent, idx) => (
    <div
      key={idx}
      className="bg-cyan-50 dark:bg-gray-800 p-6 rounded-xl shadow-lg 
                 transform transition-all duration-700 ease-in-out 
                 hover:scale-105 w-full h-96 flex flex-col"
    >
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
        {idx === 0
          ? "User Activity"
          : idx === 1
          ? "Signup Trends"
          : idx === 2
          ? "Gender Distribution"
          : "Age Distribution"}
      </h2>
      <ChartComponent allUsers={allUsers} />
    </div>
  ))}
</div>

        </div>
    </>
  );
};

export default Dashboard;
