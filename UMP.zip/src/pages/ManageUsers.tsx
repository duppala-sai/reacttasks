import React, { useState, useEffect } from "react";
import Header from "../components/header";
import UserForm from "../components/Userform";

const ManageUsers: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [editUser, setEditUser] = useState<any>(null);

  const storedUsers = localStorage.getItem("userdata");
  const allUsers = storedUsers ? JSON.parse(storedUsers) : [];

  const handleAddUser = () => {
    setEditUser(null);
    setShowForm(true);
  };

  const handleDelete = (email: string) => {
    const updatedUsers = allUsers.filter((user: any) => user.email !== email);
    localStorage.setItem("userdata", JSON.stringify(updatedUsers));
    window.location.reload();
  };

  const handleEdit = (email: string) => {
    const user = allUsers.find((u: any) => u.email === email);
    setEditUser(user);
    setShowForm(true);
  };

  useEffect(() => {
    if (showForm) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [showForm]);

  return (
    <>
      <Header />

      <div className="flex flex-col items-center bg-blue-50 mt-20 px-6 md:px-12 pb-10 space-y-8 min-h-screen">
        <div className="text-gray-800 text-center text-lg mt-8 italic font-semibold max-w-3xl mx-auto">
          A simple and clean way to manage system users. Easily browse, edit, or remove user information from the panel below.
        </div>

        <button
          onClick={handleAddUser}
          className="bg-green-600 text-white font-semibold px-6 py-2 rounded-lg shadow-md transition-all hover:bg-green-700 hover:scale-105"
        >
          + Add New User
        </button>

        <div className="w-full max-w-6xl overflow-x-auto rounded-lg shadow-md bg-white">
          <table className="w-full border-collapse">
            <thead className="bg-purple-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold">Name</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Email</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Role</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Gender</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Mobile</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">DOB</th>
                <th className="px-4 py-3 text-center text-sm font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {allUsers.map((user: any, i: number) => (
                <tr
                  key={i}
                  className="border-t hover:bg-gray-50 transition-all"
                >
                  <td className="px-4 py-3 text-sm text-gray-800">{user.fullname}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.email}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.role}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.gender}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.mobile}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.dob}</td>
                  <td className="px-4 py-3 text-sm text-center flex items-center justify-center gap-3">
                    <button
                      onClick={() => handleEdit(user.email)}
                      className="px-3 py-1 bg-blue-500 text-white rounded-md text-sm hover:bg-blue-600 transition"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(user.email)}
                      className="px-3 py-1 bg-red-500 text-white rounded-md text-sm hover:bg-red-600 transition"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showForm && (
          <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-start overflow-auto">
            <div className="bg-white rounded-xl shadow-lg p-8 w-96 max-h-[90vh] overflow-auto mt-20">
              <UserForm
                close={() => setShowForm(false)}
                existingUser={editUser}
              />
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ManageUsers;
