import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Login() {
  const [data, setData] = useState({ mail: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const storedData = localStorage.getItem("userdata");

    if (storedData) {
      const usersData = JSON.parse(storedData);

      const foundUser = usersData.find(
        (user: any) => user.email === data.mail && user.password === data.password
      );

      if (foundUser) {
        sessionStorage.setItem("currentUser", JSON.stringify(foundUser));
        toast.success("Login successful!");
        navigate("/dashboard");
      } else {
        toast.error("Invalid Email or Password!");
      }
    } else {
      toast.info("No registered users found! Please sign up first.");
    }
  };

  return (
    <div
      className="h-screen bg-cover bg-center bg-fixed flex flex-col justify-center items-center"
      style={{ backgroundImage: "url('/images/background.png')" }}
    >
      {/* Form Container */}
      <div className="relative w-85">
        {/* Logo overlapping the top border */}
        <img
          src="/images/icon.png"
          alt="Logo"
          className="h-14 w-14 absolute -top-7 left-1/2 transform -translate-x-1/2 bg-white rounded-full p-1 border border-gray-300"
        />

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="rounded-xl p-10 bg-white bg-opacity-90 border border-gray-300 shadow-xl w-full"
        >
          {/* Login Heading */}
          <h2 className="text-2xl font-semibold text-center mb-6">Login</h2>

          <input
            type="email"
            name="mail"
            value={data.mail}
            onChange={handleChange}
            placeholder="Email"
            required
            className="rounded mb-4 p-2 border border-gray-300 w-full focus:outline-none focus:border-green-500"
          />

          <input
            type="password"
            name="password"
            value={data.password}
            onChange={handleChange}
            placeholder="Password"
            required
            className="rounded mb-6 p-2 border border-gray-300 w-full focus:outline-none focus:border-green-500"
          />

          <button
            type="submit"
            className="w-full py-2 rounded-md bg-green-700 text-white font-semibold hover:bg-green-800 transition"
          >
            Login
          </button>

          <p className="text-center text-sm text-gray-700 mt-4">
            Not a member?{" "}
            <Link
              to="/signup"
              className="text-green-700 font-semibold hover:underline hover:text-green-900"
            >
              Sign Up
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
