import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

// Calculate max DOB for 18+ users
const today = new Date();
const minDOB = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());

const schema = yup.object().shape({
  fullname: yup.string().required("Full Name is required"),
  email: yup
    .string()
    .email("Invalid email format")
    .matches(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, "Email must be valid")
    .required("Email is required"),
  password: yup.string().min(6, "Password must be at least 6 characters").required("Password is required"),
  role: yup.string().required("Role is required"),
  mobile: yup.string().matches(/^\d{10}$/, "Mobile must be 10 digits").required("Mobile is required"),
  gender: yup.string().required("Gender is required"),
  dob: yup
    .date()
    .nullable()
    .transform((value, originalValue) => (originalValue === "" ? null : value))
    .max(minDOB, "You must be at least 18 years old")
    .required("Date of Birth is required"),
});

const SignUp: React.FC = () => {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: yupResolver(schema)
  });

  const onSubmit = (data: any) => {
    data.dob = new Date(data.dob).toISOString().split("T")[0];

    const existingUsers = JSON.parse(localStorage.getItem("userdata") || "[]");
    existingUsers.push({ ...data, createdAt: new Date().toISOString().split("T")[0] });
    localStorage.setItem("userdata", JSON.stringify(existingUsers));

    toast.success("Registration successful!");
    navigate("/login");
  };

  return (
    <div
      className="min-h-screen flex flex-col items-center bg-cover bg-center bg-fixed overflow-auto p-4"
      style={{ backgroundImage: "url('/images/background.png')" }}
    >
      <div className="flex flex-col items-center w-full max-w-xs mt-10 mb-20 relative">
        <img
          src="/images/icon.png"
          alt="Logo"
          className="h-14 w-14 absolute -top-7 left-1/2 transform -translate-x-1/2 bg-white rounded-full p-1 border border-gray-300"
        />

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="rounded-xl p-8 bg-white bg-opacity-90 border border-gray-300 shadow-xl w-90"
        >
          {/* Form Heading */}
          <h2 className="text-2xl font-semibold text-center mb-6">Sign Up</h2>

          <input type="text" placeholder="Full Name" {...register("fullname")} className="rounded mb-2 p-2 border border-gray-300 w-full" />
          {errors.fullname && <p className="error-text">{errors.fullname.message}</p>}

          <input type="email" placeholder="Email" {...register("email")} className="rounded mb-2 p-2 border border-gray-300 w-full" />
          {errors.email && <p className="error-text">{errors.email.message}</p>}

          <input type="password" placeholder="Password" {...register("password")} className="rounded mb-2 p-2 border border-gray-300 w-full" />
          {errors.password && <p className="error-text">{errors.password.message}</p>}

          <select {...register("role")} className="rounded mb-2 p-2 border border-gray-300 w-full">
            <option value="">Select role</option>
            <option value="Admin">Admin</option>
            <option value="Customer">Customer</option>
            <option value="Retailer">Retailer</option>
          </select>
          {errors.role && <p className="error-text">{errors.role.message}</p>}

          <input type="tel" maxLength={10} placeholder="Mobile Number" {...register("mobile")} className="rounded mb-2 p-2 border border-gray-300 w-full" />
          {errors.mobile && <p className="error-text">{errors.mobile.message}</p>}

          <div className="flex space-x-4 mb-2">
            <label className="flex items-center">
              <input type="radio" value="Male" {...register("gender")} className="mr-1" /> Male
            </label>
            <label className="flex items-center">
              <input type="radio" value="Female" {...register("gender")} className="mr-1" /> Female
            </label>
          </div>
          {errors.gender && <p className="error-text">{errors.gender.message}</p>}

          <input type="date" {...register("dob")} className="rounded mb-2 p-2 border border-gray-300 w-full" />
          {errors.dob && <p className="error-text">{errors.dob.message}</p>}

          <button type="submit" className="w-full py-2 rounded-md bg-green-700 text-white font-semibold hover:bg-green-800 transition">
            Register
          </button>
        </form>
      </div>
    </div>
  );
};

export default SignUp;
