import React, { useEffect, useState } from "react";
import { Card, Typography } from "@mui/material";
import { BarChart } from "@mui/x-charts";

interface MonthlySignup {
  month: string;
  count: number;
}

interface SignupTrendsProps {
  allUsers: any[];
}

const SignupTrends: React.FC<SignupTrendsProps> = ({ allUsers }) => {
  const [monthlyData, setMonthlyData] = useState<MonthlySignup[]>([]);

  useEffect(() => {
    const currentYear = new Date().getFullYear();

    // Filter users created this year
    const filteredUsers = allUsers.filter((u) => {
      const date = new Date(u.createdAt);
      return date.getFullYear() === currentYear;
    });

    const monthOrder = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const formatted: MonthlySignup[] = monthOrder.map((month) => {
      const count = filteredUsers.filter((u) => {
        const userMonth = new Date(u.createdAt).toLocaleString("default", { month: "short" });
        return userMonth === month;
      }).length;

      return { month, count };
    });

    setMonthlyData(formatted);
  }, [allUsers]);

  return (
    <div className="w-full max-w-xl transform transition-all duration-700 ease-in-out hover:scale-105 ">
      <Card className="p-4 rounded-xl shadow-lg">
        <Typography variant="h6" align="center" className="mb-4 font-semibold">
          Signup Trends (Monthly)
        </Typography>
        <BarChart
          xAxis={[{ data: monthlyData.map((m) => m.month), scaleType: "band" }]}
          series={[{ data: monthlyData.map((m) => m.count), label: "Signups", color: "#2563EB" }]}
          width={300}
          height={200}
        />
      </Card>
    </div>
  );
};

export default SignupTrends;
