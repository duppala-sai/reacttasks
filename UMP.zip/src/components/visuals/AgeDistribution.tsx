import React from "react";
import { Card, Typography } from "@mui/material";
import { PieChart } from "@mui/x-charts";

interface AgeDistributionPieProps {
  allUsers: any[];
}

const AgeDistribution: React.FC<AgeDistributionPieProps> = ({ allUsers }) => {
  const ageGroups = { "18-25": 0, "26-35": 0, "36-50": 0, "50+": 0 };

  allUsers.forEach(user => {
    if (user.dob) {
      const age = Math.floor((new Date().getTime() - new Date(user.dob).getTime()) / (365 * 24 * 60 * 60 * 1000));
      if (age >= 18 && age <= 25) ageGroups["18-25"]++;
      else if (age >= 26 && age <= 35) ageGroups["26-35"]++;
      else if (age >= 36 && age <= 50) ageGroups["36-50"]++;
      else if (age > 50) ageGroups["50+"]++;
    }
  });

  const data = Object.entries(ageGroups).map(([label, value], idx) => ({
    id: idx,
    label,
    value,
    color: ["#3B82F6", "#EC4899", "#FBBF24", "#10B981"][idx],
  }));

  return (
    <Card className="p-4 rounded-xl shadow-lg transform transition-all duration-700 ease-in-out hover:scale-105 w-full max-w-xl">
      <Typography variant="h6" align="center" className="mb-4 font-semibold">
        Age Breakdown
      </Typography>
      <PieChart series={[{ data, outerRadius: 100 }]} width={300} height={200} />
    </Card>
  );
};

export default AgeDistribution;
