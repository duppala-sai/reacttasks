import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { toast } from "react-toastify";

interface UserFormProps {
  close: () => void;
  existingUser?: any;
}

const today = new Date();
const minDOB = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());

const schema = yup.object().shape({
  fullname: yup.string().required("Full Name is required"),
  email: yup.string().email("Invalid email format").required("Email is required"),
  password: yup.string().min(6, "Password must be at least 6 characters"),
  role: yup.string().required("Role is required"),
  mobile: yup.string().matches(/^\d{10}$/, "Mobile must be 10 digits").required("Mobile is required"),
  gender: yup.string().required("Gender is required"),
  dob: yup
    .date()
    .nullable()
    .transform((value, originalValue) => (originalValue === "" ? null : value))
    .max(minDOB, "You must be at least 18 years old")
    .required("Date of Birth is required"),
});

const UserForm: React.FC<UserFormProps> = ({ close, existingUser }) => {
  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    if (existingUser) {
      Object.keys(existingUser).forEach((key) => setValue(key as any, existingUser[key]));
    }
  }, [existingUser, setValue]);

  const onSubmit = (data: any) => {
    if (data.dob) data.dob = new Date(data.dob).toISOString().split("T")[0];

    const existingUsers = JSON.parse(localStorage.getItem("userdata") || "[]");

    if (existingUser) {
      const updatedUsers = existingUsers.map((u: any) => u.email === existingUser.email ? { ...data } : u);
      localStorage.setItem("userdata", JSON.stringify(updatedUsers));
      toast.success("User updated successfully!");
    } else {
      existingUsers.push({ ...data, createdAt: new Date().toISOString().split("T")[0] });
      localStorage.setItem("userdata", JSON.stringify(existingUsers));
      toast.success("User added successfully!");
    }

    close();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50">
      <div className="bg-white rounded-xl shadow-lg w-96 p-6 relative">
        <h2 className="text-xl font-semibold mb-4">{existingUser ? "Edit User" : "Add New User"}</h2>

        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3">
          <input type="text" placeholder="Full Name" {...register("fullname")} className="border rounded p-2 w-full" />
          {errors.fullname && <p className="error-text">{errors.fullname.message}</p>}

          <input type="email" placeholder="Email" {...register("email")} disabled={!!existingUser} className="border rounded p-2 w-full" />
          {errors.email && <p className="error-text">{errors.email.message}</p>}

          {!existingUser && (
            <>
              <input type="password" placeholder="Password" {...register("password")} className="border rounded p-2 w-full" />
              {errors.password && <p className="error-text">{errors.password.message}</p>}
            </>
          )}

          <select {...register("role")} className="border rounded p-2 w-full">
            <option value="">Select Role</option>
            <option value="Admin">Admin</option>
            <option value="Customer">Customer</option>
            <option value="Retailer">Retailer</option>
          </select>
          {errors.role && <p className="error-text">{errors.role.message}</p>}

          <input type="tel" placeholder="Mobile Number" {...register("mobile")} maxLength={10} className="border rounded p-2 w-full" />
          {errors.mobile && <p className="error-text">{errors.mobile.message}</p>}

          <div className="flex gap-4 items-center">
            <label className="flex items-center gap-1">
              <input type="radio" {...register("gender")} value="Male" /> Male
            </label>
            <label className="flex items-center gap-1">
              <input type="radio" {...register("gender")} value="Female" /> Female
            </label>
          </div>
          {errors.gender && <p className="error-text">{errors.gender.message}</p>}

          <input type="date" {...register("dob")} className="border rounded p-2 w-full" />
          {errors.dob && <p className="error-text">{errors.dob.message}</p>}

          <div className="flex justify-end gap-3 mt-2">
            <button type="submit" className="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700 transition">
              {existingUser ? "Update" : "Add"}
            </button>
            <button type="button" onClick={close} className="bg-gray-500 text-white px-4 py-1 rounded hover:bg-gray-600 transition">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserForm;
