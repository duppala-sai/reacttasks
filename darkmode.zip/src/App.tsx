import React from "react";
import Tail from "./components/tail";

const App: React.FC = () => {
  return (
    <div>
      <Tail />
    </div>
  );
};

export default App;
