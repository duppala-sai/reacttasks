import { useState } from "react";
function Tail() {
  const [theme,setTheme]= useState("light");
  const tog=() =>{
  const newTheme=theme === "light" ? "dark" : "light";
  setTheme(newTheme);
  document.documentElement.classList.toggle("dark",newTheme === "dark");
}
  return (
    <>
    <div className='flex items-center justify-center min-h-screen  dark:bg-gray-700 transition-all ease-in-out'>
    <button
    onClick={tog}
    className=' dark:bg-blue-300 border-2 rounded-2xl transition-all ease-in-out'>shift</button>
    </div>
    </>
  )
}

export default Tail